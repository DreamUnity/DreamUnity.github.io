#! /bin/bash
cd 
cd Blog/typoraImage
git pull origin master
git add .
git commit -m '提交图片'
git push origin master

# read -p "Please input the name of file:" FILE_NAME
# python3 /Users/dreamyouth/Blog/dingyidreams/source/_posts/replace_url.py ${FILE_NAME}