import os
import re
import sys
import shutil

mode = "copy"

def image_operation(old_path, new_path, mode="copy"):
	if mode == "copy":
		shutil.copyfile(old_path, new_path)
	elif mode == "move":
		os.rename(old_path, new_path)

org_filename = str(sys.argv[1])
series_name = org_filename.lower().replace(".md", "")

with open(org_filename, "r", encoding="utf-8") as f:
	lines = f.readlines()

new_lines = []
image_count = 0
src_pattern = r'src=".*?\.png" '
alt_pattern = r'alt=".*?" '
src_pattern_no_resize = r"\(.*?\.png\)"
alt_pattern_no_resize = r"\!\[.*?\]"

# image_folder = "/Users/daning/Library/Application Support/typora-user-images/"
image_folder = "/Users/dreamyouth/Library/Application Support/typora-user-images/"
new_image_folder = "/Users/dreamyouth/Blog/typoraImage/"
cdn_path = "https://cdn.jsdelivr.net/gh/DreamUnity/typoraImage/"
# image_folder = new_image_folder

for line in lines:
	src_check = re.search(src_pattern, line)
	src_no_size_check = re.search(src_pattern_no_resize, line)
	if src_check is not None:
		src_group = src_check.group()
		if cdn_path not in src_group:
			image_count += 1
			old_path = re.search(r'".*?"', src_group).group().replace('\"', "")

			new_file_name = "{}{}.png".format(series_name, image_count)
			new_path = new_image_folder + new_file_name

			try:
				image_operation(old_path, new_path, mode)
				# pass
			except FileNotFoundError as e:
				print(e)

			new_path = cdn_path + new_file_name
			line = re.sub(src_pattern, r'src="{}" '.format(new_path), line)
		new_line = re.sub(alt_pattern, "", line)
		print(new_line)

	elif src_no_size_check is not None:
		src_group = src_no_size_check.group()
		if cdn_path not in src_group:
			image_count += 1
			old_path = src_group.replace("(", "")
			old_path = old_path.replace(")", "")
			new_file_name = "{}{}.png".format(series_name, image_count)
			new_path = new_image_folder + new_file_name

			try:
				image_operation(old_path, new_path, mode)
				# pass
			except FileNotFoundError as e:
				print(e)

			new_path = cdn_path + new_file_name
			line = re.sub(src_group, new_path, line)

		# remove alt
		new_line = re.sub(alt_pattern_no_resize, "![]", line)

	else:
		new_line = line
	new_lines.append(new_line)




with open("copy_" + org_filename, "w", encoding="utf-8") as f:
	f.writelines(new_lines)
print("-----------已经完成转换！------------")