---
title: MySQL_表空间
mathjax: false
top: false
keywords: MySql
categories: MySql
tags: Mysql
abbrlink: 3823
date: 2022-08-12 19:24:57
summary:
password:
img: https://img-blog.csdnimg.cn/19b9384ccd4e4f66a213b7e7fb0ca1e9.jpeg
---

# 表在文件系统中的表示
InnoDB存储表数据的方式：
- 每个索引对应一个b+树，每个节点都是一个数据页，用双链表连接
- 叶子节点存储了完整的用户记录

管理这些页：表空间（系统表空间、独立表空间[为每个表建立一个]、其他类型表空间[通用表\undo\临时表]）

MyISAM存储表数据的方式：
没有表空间一说，表的数据和索引数据都存放在数据库子目录下

# InnoDB的表空间
## 独立表空间结构
### 区的概念
==64页-1区   256区-1组==
- 第一个组的最开始的3个页面类型是固定的
- * FSP_HDR记录表空间整体属性以及所有区的属性，整个表空间只有过一个FSP_HDR类型页面
- * IBUF_BITMAP存储有关Change Buffer的一些信息
-  * INODE存储INODE Entry的数据结构
- 其余的各组的两个页面的类型是固定的
- * XDES（extent descriptor）用来登记本组256个区的属性，与FSP_HDR作用类似但是FSP_HDR会额外存储一些表空间的属性
- * IBUF_BITMAP存储有关Change Buffer的一些信息
### 段的概念
`索引->叶子段、非叶子段`
碎片区：碎片区的页可以用于不同目的，其中可以有的页属段A，有的页属段B，有的直接属表空间。

- 刚插入数据时，段从某个碎片区以单个页来分配空间
- 段占用32个碎片区页面之后，以完整的区为单位分配存储空间
==段是某些零散的页面以及一些完整的区的集合==
### 区的分类 XDES Entry
- FREE 区的分类
- FREE_FRAG 有剩余空闲页面的碎片区
- FULL_FRAG 没有剩余空闲页面的碎片区
- FSEG 附属于某个段的区

FREE 、FREE_FRAG 、FULL_FRAG属于表空间

XDES Entry 管理以上的==区==
![](https://img-blog.csdnimg.cn/78c208b593ae4416815744bc9757ae62.png)

- Segment ID 该区所在的段的ID
- List Node 将若干个XDES Entry连成一个链表
- State 区的状态，即以上四个
- Page State Bitmap 16字节-128位。一个区有64的页，这128位分为64个部分，每部分的第一位表示对应的表是否空闲，第二位还没用到

通过XDES Entry结构中的List Node建成链表，将状态对应的区对应的XDES Entry结构连接成一个链表，==直属于表空间==
- FREE链表
- FREE_FRAG链表
- FULL_FRAG链表

根据段号建立链表，为每个段中的区的XDES Entry结构建立了3个链表，==属于段==
- FREE链表
- NOT_FULL链表
- FULL链表

List Base Node（链表及节点）结构，包含了链表的头节点和尾节点等
![](https://img-blog.csdnimg.cn/02a0a03ea0c54fdaa9750cc2c94266b7.png)

### 段的结构 INODE Entry
==段是一个逻辑上的概念==

- NOT_FULL_N_USED 在NOT_FULL链表中使用了多少个页面
- MagicNumber 标记INODE Entry是否被初始化
- Fragment Array Entry 每个对应着一个零散的页面，表页号

![](https://img-blog.csdnimg.cn/e5e8fbfe83d543508a17c181cd18b0c0.png)

### 各类型页面
- * FSP_HDR类型：第一个组的第一个页面，即表空间的第一个页面，存储表空间的整体属性及其第一个组的256个XDES Entry结构
![](https://img-blog.csdnimg.cn/df76a34bdfca434daaa788eea6959cc7.png)

- * XDES类型：只是不记录表空间的整体属性 ![](https://img-blog.csdnimg.cn/fce8506ad3874b0da0ca214f154d57a6.png)

- * IBUF_BITMAP了类型：记录了有关Change Buffer的东西


- * INODE类型：为了存储INODE Entry结构，其中，List Node For INODE Page List通用链表节点，存储上一个和下一个INODE页面的指针，当段超过85个时，需要额外的INODE类型的页面存储。讲这些INODE类型的页面串成两个不同链表
- * * SEG_INODES_FULL
- * * SEG_INODES_FREE
![](https://img-blog.csdnimg.cn/910931f96e304d858e7d2b871427c4d9.png)

### Segment Header 结构的运用
==如何知道哪个段对应哪个INODE Entry结构==
- Space ID 表空间ID
- Page Number 所在的页面页号
- Byte Offset 偏移量
![](https://img-blog.csdnimg.cn/c5874ad637604f7e853e2faad760c5fc.png)

## 系统表空间
==开头有许多记录整个系统属性的页面==
前1-3页面的类型是与独立表空间  一致的，但后3-7是系统表特有的
- SYS：存储Change Buffer的头部信息
- INDEX：存储Change Buffer的根页面
- TRX_SYS： 事务系统的相关信息
- SYS：第一个回滚段的信息
- SYS：数据字典头部信息

其中extent 1和extent 2成为双写缓冲区。

![](https://img-blog.csdnimg.cn/64075a08ef5843599fb86c24347498ba.png)
### InnoDB数据字典

每当向一个表插入一条数据时，需要进行一系列的校验。使用的信息不是使用INSERT语句插入的用户数据，需要引入一些额外数据---==元数据==
其中有4个表尤其重要，如下‼️
- SYS_TABLES 所有表信息
- * 以NAME列为主键的聚簇索引
- * 以ID为列建立的二级索引
- SYS_COLUMNS 所有列信息
- * 只有一个以(TABLE_ID, POS)建立的聚簇索引
- SYS_INDEXES 所有索引信息
- * 只有一个以(TABLE_ID, ID)列为主键的聚簇索引
- SYS_FIELDS 所有索引对应的列的信息
- * 只有一个以（INDEX_ID, POS)列为主键的聚簇索引

Data Dictionary Header页面：有了上述的4张表，可以获取其他系统表以及用户定义的表的所有元数据。
1. 根据表名到SYS_TABLES表中定位到`表的TABLE_ID`
2. 使用TABLE_ID到SYS_CCOLUMNS表中获取`所有列`的信息
3. 使用TABLE_ID到SYS_INDEXES表中获取`所有索引`的信息
4. 使用TABLE_ID到SYS_FIELDS表中获取所有索引列的信息

==使用类型为SYS的页面记录上述4张表==
