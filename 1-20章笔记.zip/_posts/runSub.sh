#! /bin/bash
read -p "Please input the name of file:" FILE_NAME
echo your input filename = $FILE_NAME
python3 replace_url.py $FILE_NAME
raw_dir="/Users/dreamyouth/Downloads/文稿存档/博客备份"
now_dir="/Users/dreamyouth/Blog/dingyidreams/source/_posts"
dir_new=$raw_dir"/"$FILE_NAME
dir_old=$now_dir"/"$FILE_NAME
mv $dir_old $dir_new
new_name="copy_"$FILE_NAME
mv $new_name $FILE_NAME

echo 文件转换操作完成！现在开始上传文件

cd
cd Blog/dingyidreams
hexo cl && hexo g && hexo d
cd 
cd Blog/typoraImage
git pull origin master
git add .
git commit -m '提交图片'
git push origin master

echo ok啦