#! /bin/bash
read -p "Please input the name of file:" FILE_NAME
echo your input filename = FILE_NAME
python3 replace_url.py $FILE_NAME
raw_dir="/Users/dreamyouth/Downloads/文稿存档/博客备份"
now_dir="/Users/dreamyouth/Blog/dingyidreams/source/_posts"
dir_new=$raw_dir"/"$FILE_NAME
dir_old=$now_dir"/"$FILE_NAME
mv $dir_old $dir_new

echo 操作完成！